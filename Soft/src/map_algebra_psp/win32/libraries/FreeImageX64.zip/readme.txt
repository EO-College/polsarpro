Warning !
_________

This library is the freeimage library v3.13.1 which can be found at the address http://freeimage.sourceforge.net.

I rebuilded the library to target 64 applications.

!! Use it with no warranty !!


If you want to know how I proceeded to target X64 processors, 
check the article on http://www.sambeauvois.be/blog/2010/05/freeimage-and-x64-projects-yes-you-can/




Sam Beauvois

Find me on the web :

- http://www.sambeauvois.be
- http://www.twitter.com/sambeauvois
